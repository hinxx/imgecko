#ifndef __GECKOMEM_H__
#define __GECKOMEM_H__


int gecko_readmem();
int gecko_readrange(u32 memstart, u32 memend);

#endif
