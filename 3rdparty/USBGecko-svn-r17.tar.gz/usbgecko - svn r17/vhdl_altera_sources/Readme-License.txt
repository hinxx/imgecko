All USB Gecko Hardware is licensed under BSD license.
For a copy of the license please visit:
http://www.opensource.org/licenses/bsd-license.php